import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/main.css';

import 'regenerator-runtime';
import main from './scripts/main';

main();
